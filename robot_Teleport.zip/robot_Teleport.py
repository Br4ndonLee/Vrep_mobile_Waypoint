try:
    import vrep
except:
    print ('--------------------------------------------------------------')
    print ('"vrep.py" could not be imported. This means very probably that')
    print ('either "vrep.py" or the remoteApi library could not be found.')
    print ('Make sure both are in the same folder as this file,')
    print ('or appropriately adjust the file "vrep.py"')
    print ('--------------------------------------------------------------')
    print ('')

from pydoc import cli
import time
import numpy as np
import yaml
import argparse
import math

vrep.simxFinish(-1) # just in case, close all opened connections
clientID=vrep.simxStart('127.0.0.1',19997,True,True,5000,5) # Connect to V-REP
if clientID!=-1:

    print ('Connected to remote API server')

    # 2.a: Handle the Pioneer:
    res , pioneerHandle = vrep.simxGetObjectHandle(clientID, "Pioneer_p3dx", vrep.simx_opmode_blocking)
    res,  pioneerLeftMotor = vrep.simxGetObjectHandle(clientID, "left", vrep.simx_opmode_blocking)
    res,  pioneerRightMotor = vrep.simxGetObjectHandle(clientID, "right", vrep.simx_opmode_blocking)
    res, pioneerOrientation = vrep.simxGetObjectOrientation(clientID, pioneerHandle, -1, vrep.simx_opmode_streaming)


    # Get the position of the Pioneer for the first time in streaming mode: Still have to understand why this is done!
    res , pioneerPosition = vrep.simxGetObjectPosition(clientID, pioneerHandle, 1 , vrep.simx_opmode_streaming)


    ### Step 3: Start the Simulation: Keep printing out status messages!!!
    
    res = vrep.simxStartSimulation(clientID, vrep.simx_opmode_oneshot_wait)

    
    if res == vrep.simx_return_ok:

        print ("---!!! Started Simulation !!! ---")
        
    
    # Paht for robots
    output_path = []
    output_time=[]
    radian = []
    degree = []
    radian_list = []
    degree_list = []
    z = 0.15
    dt = 0.1
    scale = 1

    # Get coordinate from output.yaml
    with open("output.yaml", 'r') as output_file:
        data = yaml.load(output_file, Loader=yaml.FullLoader)
        agent1 = data['agent1']    
        agent0 = data['agent0']
    
    # set agent
    # for element in agent0:
    for element in agent1:
        x = element['x'] * scale
        y = element['y'] * scale
        z = 0.15
        t = element['t']
        coordinates = [x, y, z]
        element_time = t
        output_time.append(element_time)
        output_path.append(coordinates)
    print(output_time)
    
    # for i in range(len(output_path)-1):
    #     radian = math.atan2(output_path[i+1][1]-output_path[i][1], output_path[i+1][0]-output_path[i][0])
    #     degree = math.degrees(radian)
    #     radian_list.append(radian)
    #     degree_list.append(degree)

    # for j in range(len(output_path)-1):
    #     output_path[j].append(degree_list[j])
    # output_path[-1].append(degree_list[-1])
    
    # output_path[len(output_path)-1].append()
    output_path[0].append(180)
    for i in range(len(output_path)-1):
        radian = math.atan2(output_path[i+1][1]-output_path[i][1], output_path[i+1][0]-output_path[i][0])
        degree = math.degrees(radian)
        output_path[i+1].append(degree)

    # [t, x, y, theta]
    # input_path = [[0, 0, 0, 0],[1, 2, 0, 0], [2, 2, 0, 90], [3, 2, 2, 90], [4, 2, 2, -90], [5, 2, 0, -90], [6, 2, -2, -90],]
    # input_path = [[0, 0, 0, 0],[0.4, 2, 0, 0], [0.6, 2, 0, 90], [1.6, 2, 2, 90], [2.0, 2, 2, -90], [4, 2, 0, -90], [8, 2, -2, -90]]
    
    print(output_path)

    # robot_path = [x, y, z, yaw]
    robot_path = []
    robot_orient = []
    robot_time = []

    radian_to_degree =[]

    robot_path.append([output_path[0][0], output_path[0][1], output_path[0][2]])
    robot_orient.append([0, 0, math.radians(output_path[i][3])])
    prev_angle = 180.0
    current_angle = 0
    turn_time_ratio = 0.5
    for i in range(len(output_path)-1):
        t = output_time[i]*100.0
        t_prime = output_time[i+1]*100.0
        tdt = (t_prime - t)/100.0
        
        # check 
        tdt_for_turn = 0
        tdt_for_go = tdt

        current_angle = output_path[i][3]
        if prev_angle != current_angle:
            tdt_for_turn = tdt*turn_time_ratio
            tdt_for_go = tdt - tdt_for_turn
        
        # get x coordinate & calculate difference with x and x+1
        x = output_path[i][0]
        x_prime = output_path[i+1][0]
        xdt = (x_prime - x)*dt/tdt_for_go

        # get y coordinate & calculate difference with y and y+1
        y = output_path[i][1]
        y_prime = output_path[i+1][1]
        ydt = (y_prime - y)*dt/tdt_for_go

        # get yaw coordinate & calculate difference with yaw and yaw+1
        yaw_before = 0.0
        if i>0:
            yaw_before = math.radians(output_path[i-1][3])
        yaw = math.radians(output_path[i][3])
        yaw_prime = math.radians(output_path[i+1][3])
        if tdt_for_turn == 0:
            yawdt = 0
        else:
            yawdt = (yaw - yaw_before)*dt/tdt_for_turn

        n = int(tdt_for_turn/dt)
        for a in range (n):
            yaw += yawdt
            direction = [0,0, yaw]
            coordinate = [x, y, z]
            robot_orient.append(direction)
            robot_path.append(coordinate)
            # radian_to_degree.append(math.degrees(yaw))
            # robot_time.append(tdt)

        n = int(tdt_for_go/dt)
        for a in range (n):
            x += xdt
            y += ydt
            coordinate = [x, y, z]
            direction = [0,0, yaw]
            robot_path.append(coordinate)
            robot_orient.append(direction)
        
        print("")
        prev_angle = current_angle

    # print(robot_path)
        # robot_coordinate = [x, y, z]
        # robot_direction = [0, 0, yaw]
        # robot_time.append(dt)
        # robot_path.append(robot_coordinate)
        # robot_orient.append(robot_direction)

    print("##################################")
    print(robot_path)
    print("number is", len(robot_path))
    print("##################################")
    print(robot_orient)
    print("number is", len(robot_orient))
    print("##################################")
    for i in range(len(robot_path)):
        print(robot_path[i], robot_orient[i])
    # print(robot_path)
    # print("##################################")
    # print(robot_orient)


    for p in range(len(robot_path)):
        # if robot_orient[p] == robot_orient[p-1]:
        vrep.simxSetObjectPosition(clientID, pioneerHandle, -1, robot_path[p], vrep.simx_opmode_oneshot_wait)
        vrep.simxSetObjectOrientation(clientID, pioneerHandle, -1, robot_orient[p], vrep.simx_opmode_oneshot_wait)
            
            

        time.sleep(dt)

    # Stop the simulation
    res = vrep.simxStopSimulation(clientID, vrep.simx_opmode_oneshot_wait)
    if res == vrep.simx_return_ok:
        print("Stop Simulation") 